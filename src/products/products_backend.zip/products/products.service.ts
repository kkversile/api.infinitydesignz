import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { CreateProductsDto } from './dto';
@Injectable()
export class ProductsService {
  constructor(private readonly prisma: PrismaService) {}

 async getFullProductDetails(productId: number) {
    return this.prisma.product.findUnique({
      where: { id: productId },
      include: {
        variants: true,
        images: true,
        filters: true,         // ✅ Corrected
      features: true         // ✅ Optional if needed
      },
    });
  }
  async create(data: CreateProductsDto) {
    const {
      sku,
      title,
      description,
      brandId,
      categoryId,
      colorId,
      sizeId,
      stock,
      mrp,
      sellingPrice,
      height,
      width,
      length,
      searchKeywords,
      status,
      productDetails,
      variants,
    } = data;

    return this.prisma.product.create({
      data: {
        sku,
        title,
        description,
        status,
        mrp,
        sellingPrice,
        stock,
        height,
        width,
        length,
        searchKeywords,
        size: sizeId ? { connect: { id: sizeId } } : undefined,
        color: colorId ? { connect: { id: colorId } } : undefined,
        category: { connect: { id: categoryId } },
        brand: { connect: { id: brandId } },
        productDetails: {
          create: {
            model: productDetails?.model ?? '',
            weight: productDetails?.weight,
            sla: productDetails?.sla,
            deliveryCharges: productDetails?.deliveryCharges,
          },
        },
        variants: {
          create: variants?.map((v) => ({
            sku: v.sku,
            stock: v.stock,
            mrp: v.mrp,
            sellingPrice: v.sellingPrice,
            size: v.sizeId ? { connect: { id: v.sizeId } } : undefined,
            color: v.colorId ? { connect: { id: v.colorId } } : undefined,
          })) ?? [],
        },
      },
    });
  }
  findAll() {
    return this.prisma.product.findMany();
  }

  findOne(id: number) {
    return this.prisma.product.findUnique({ where: { id } });
  }

  update(id: number, data: any) {
    return this.prisma.product.update({ where: { id }, data });
  }

  remove(id: number) {
    return this.prisma.product.delete({ where: { id } });
  }
}