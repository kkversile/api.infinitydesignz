import { Controller, Get, Post, Body, Param, Put, Delete } from '@nestjs/common';
import { ImagesService } from './images.service';
import { CreateImagesDto, UpdateImagesDto } from './dto';

@Controller('images')
export class ImagesController {
  constructor(private readonly imagesService: ImagesService) {}

  @Post()
  create(@Body() dto: CreateImagesDto) {
    return this.imagesService.create(dto);
  }

  @Get()
  findAll() {
    return this.imagesService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.imagesService.findOne(+id);
  }

  @Put(':id')
  update(@Param('id') id: string, @Body() dto: UpdateImagesDto) {
    return this.imagesService.update(+id, dto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.imagesService.remove(+id);
  }
}