export class CreateProductfiltersDto {}
export class UpdateProductfiltersDto {}