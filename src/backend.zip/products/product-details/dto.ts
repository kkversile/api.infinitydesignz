export class CreateProductdetailsDto {}
export class UpdateProductdetailsDto {}