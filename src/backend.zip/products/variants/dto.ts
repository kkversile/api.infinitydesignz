export class CreateVariantsDto {}
export class UpdateVariantsDto {}