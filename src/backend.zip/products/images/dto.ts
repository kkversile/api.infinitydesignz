export class CreateImagesDto {}
export class UpdateImagesDto {}