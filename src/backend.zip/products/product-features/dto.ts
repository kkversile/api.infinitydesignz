export class CreateProductFeatureDto {
  productId: number;
  featureId: number;
  value: string;
}
