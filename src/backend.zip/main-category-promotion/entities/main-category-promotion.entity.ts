
export class MainCategoryPromotion {
  id: number;
  title: string;
  image_url: string;
  position: string;
  display_count: number;
  display_rows: number;
  status: boolean;
  created_at: Date;
}
