
export class UpdateMainCategoryPromotionDto {
  title?: string;
  position?: string;
  display_count?: number;
  display_rows?: number;
  status?: boolean;
}
