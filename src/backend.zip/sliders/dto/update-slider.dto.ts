export class UpdateSliderDto {
  title?: string;
  link?: string;
  priority?: number;
  status?: boolean;
}
