// dto/create-main-product-promotion.dto.ts
import { IsBoolean, IsInt, IsNumber, IsOptional, IsPositive, IsString, IsUrl, MaxLength, Min } from 'class-validator';

export class CreateMainProductPromotionDto {
  @IsString()
  title: string;

  @IsInt()
  @IsOptional()
  priority?: number;

  @IsInt()
  mainCategoryPromotionId: number; // FK instead of displayPosition string

  @IsString()
  // or @IsUrl() if you want strict URL validation
  imageUrl: string;

  @IsInt()
  categoryId: number;

  @IsInt()
  @IsOptional()
  brandId?: number;

  @IsString()
  @IsOptional()
  seller?: string;

  @IsNumber()
  @IsOptional()
  minPrice?: number;

  @IsNumber()
  @IsOptional()
  maxPrice?: number;

  @IsNumber()
  @IsOptional()
  offerPercentFrom?: number;

  @IsNumber()
  @IsOptional()
  offerPercentTo?: number;

  @IsString()
  @IsOptional()
  @MaxLength(160)
  seoTitle?: string;

  @IsString()
  @IsOptional()
  @MaxLength(255)
  seoDescription?: string;

  @IsString()
  @IsOptional()
  @MaxLength(255)
  seoKeywords?: string;

  @IsBoolean()
  @IsOptional()
  status?: boolean;
}
